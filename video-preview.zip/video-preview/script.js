console.log("page loaded...");

function play(element) {
    element.play()
}